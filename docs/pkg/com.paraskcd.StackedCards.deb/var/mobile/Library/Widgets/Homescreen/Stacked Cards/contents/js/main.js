(function(){
    loadTime(api.system);
    loadWeather(api.weather);
    loadMusic(api.media);
    loadStorage();
    checkSettings();
    loadApps(api.apps);
    taphold({
        time: 400,
        element: doc.getElementById("favAppsBody"),
        action: function(element) {
            console.log(changingApp);
            tapHoldOnIcon(element);
        },
        passTarget: true
    });
}());

api.system.observeData(function(systemData) {
    loadTime(systemData);
});

api.weather.observeData(function(weatherData) {
    loadWeather(weatherData);
});

api.media.observeData(function(musicData) {
    loadMusic(musicData);
});

api.media.observeElapsedTime(function (newElapsedTime) {
    handleTrackTimes(newElapsedTime, api.media.nowPlaying.length, false);
    handleScrobblePosition(newElapsedTime, api.media.nowPlaying.length);
});

api.apps.observeData(function(appData) {
    loadApps(appData);
});