////////////////////////////////////////////////////////////////////////////////////////////////////
//VARIABLES
///////////////////////////////////////////////////////////////////////////////////////////////////   
var doc = document;

var touchMoved = false,
    changingApp = false,
    target = null;
let scrobbleIsDragging = false;

var dayContainer = doc.getElementById("dayContainer"),
    clockContainer = doc.getElementById("clockContainer"),
    timeContainer = doc.getElementById("timeContainer"),
    weatherTemp = doc.getElementById("weatherTemp"),
    stackDiv = doc.getElementById("stack"),
    weatherBody = doc.getElementById("weatherBody"),
    musicArtwork = doc.getElementById("musicArtwork"),
    play = doc.getElementById("play"),
    musicTrack = doc.getElementById("musicTrack"),
    musicArtist = doc.getElementById("musicArtist"),
    favAppsBody = doc.getElementById("favAppsBody"),
    menu = doc.getElementById("menu");

var stacks = doc.getElementsByClassName("stacked"),
    musicButtons = doc.getElementsByClassName("musicButtons");

//Settings
var hideTime = false,
    disableWeather = false,
    disableMusic = false,
    disableApp = false,
    weatherBgColor = "#03a9f447";
    musicBgColor = "#a153af47";
    favAppsBgColor = "#ca2b4a47";

////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////   

function createDOM(params) {
    var element = doc.createElement(params.type);
    if(params.id) {
        element.id = params.id;
    }
    if(params.className) {
        element.className = params.className;
    }
    if(params.innerHTML) {
        element.innerHTML = params.innerHTML;
    }
    if(params.styleImg) {
        element.style.backgroundImage = "url(" + params.styleImg + ")";
    }
    if(params.appender) {
        for(let i = 0; i < params.appender.length; i++) {
            element.appendChild(params.appender[i]);
        }
    }
    return element;
}

function createToggle(params) {
    var infoIcon = createDOM({
            className: 'infoIcon'
        });

    addEventToInfo(infoIcon, params.info);

    var label = createDOM({
            type: "div",
            className: "settingsLabel",
            innerHTML: params.label
        }),
        checkbox = createDOM({
            type: "input",
            id: params.id,
        }),
        span = createDOM({
            className: "slider"
        });

    checkbox.type = "checkbox";
    checkbox.oninput = function() {
        if(checkbox.checked) {
            params.bool = true;
            theStorage.replaceValueInLS("" + params.id, params.bool);
            checkSettings();
        } else {
            params.bool = false;
            theStorage.replaceValueInLS("" + params.id, params.bool);
            checkSettings();
        }
    }

    if(theStorage["" + params.id]) {
        checkbox.checked = true;
    }

    var toggle = createDOM({
            type: "label",
            className: "switch",
            appender: [checkbox, span]
        });

    childAppender({
        div: params.el,
        children: [label, toggle, infoIcon]
    });

}

function destroySettings(div) {
    div.classList.add("close");
    div.innerHTML = "";
    setTimeout(function() {
        requestAnimationFrame(() => {
            doc.body.removeChild(div);
        });
    }, 350);
}

function childAppender(params) {
    for(let i = 0; i < params.children.length; i++) {
        params.div.appendChild(params.children[i]);
    }
}

function addEventToInfo(infoIcon, info) {
    infoIcon.addEventListener("touchend", function() {
        thePrompter({
            type: "alert",
            message: info,
            promptYesText: "Cool!",
            promptYes: function() {}
        });
    });
}

function addStyle(str, id) {
    var element, node;
    if (id) {
        if (doc.getElementById(id)) {
            element = doc.getElementById(id);
            doc.body.removeChild(element);
        }
    }
    node = doc.createElement('style');
    node.innerHTML = str;
    node.id = id;
    doc.body.appendChild(node);
}

function checkSettings() {
    if(hideSettings) {
        addStyle("#menu {display: none;}", "disableSettingsButton");
    }

    if(theStorage["hideTime"]) {
        addStyle("#timeContainer {display: none;}", "disableTimeSettings");
    } else {
        addStyle("", "disableTimeSettings");
    }

    if(theStorage["disableWeather"]) {
        addStyle("#weather.stacked {display: none;} #timeContainer {bottom: 170px;}", "disableStack");
    } else if(theStorage["disableMusic"]) {
        addStyle("#music.stacked {display: none;} #weather.stacked {transform: translate(-50%, 510px);} #timeContainer {bottom: 170px;} @media only screen and (device-width : 375px) and (device-height : 812px) {#weather.stacked {transform: translate(-50%, 455px);}} @media only screen and (device-width : 414px) and (device-height : 736px) {#weather.stacked {transform: translate(-50%, 390px);}} @media only screen and (device-width : 375px) and (device-height : 667px) {#weather.stacked {transform: translate(-50%, 340px);}} @media only screen and (device-width : 320px) and (device-height : 568px) {#weather.stacked {transform: translate(-50%, 280px);}}", "disableStack");
    } else if(theStorage["disableApp"]) {
        addStyle("#favApps.stacked {display: none;} #weather.stacked {transform: translate(-50%, 510px);} #music.stacked {transform: translate(-50%, 595px);} #timeContainer {bottom: 170px;} @media only screen and (device-width : 375px) and (device-height : 812px) {#music.stacked {transform: translate(-50%, 530px);} #weather.stacked {transform: translate(-50%, 440px);}} @media only screen and (device-width : 414px) and (device-height : 736px) {#music.stacked {transform: translate(-50%, 475px);} #weather.stacked {transform: translate(-50%, 385px);}} @media only screen and (device-width : 375px) and (device-height : 667px) {#music.stacked {transform: translate(-50%, 425px);} #weather.stacked {transform: translate(-50%, 335px);}} @media only screen and (device-width : 320px) and (device-height : 568px) {#music.stacked {transform: translate(-50%, 355px);} #weather.stacked {transform: translate(-50%, 265px);}}", "disableStack");
    } else {
        addStyle("", "disableStack");
    }
    
    if(theStorage["disableApp"] && theStorage["disableWeather"]) {
        addStyle("#weather.stacked {display: none;} #favApps.stacked {display: none;} #music.stacked {transform: translate(-50%, 595px);} #timeContainer {bottom: 105px;} @media only screen and (device-width : 375px) and (device-height : 812px) {#music.stacked {transform: translate(-50%, 530px);}} @media only screen and (device-width : 414px) and (device-height : 736px) {#music.stacked {transform: translate(-50%, 475px);}} @media only screen and (device-width : 375px) and (device-height : 667px) {#music.stacked {transform: translate(-50%, 425px);}} @media only screen and (device-width : 320px) and (device-height : 568px) {#music.stacked {transform: translate(-50%, 355px);}}", "disableStack");
    } else if(theStorage["disableWeather"] && theStorage["disableMusic"]) {
        addStyle("#weather.stacked {display: none;} #music.stacked {display: none;} #favApps.stacked {transform: translate(-50%, 595px);} #timeContainer {bottom: 105px;} @media only screen and (device-width : 375px) and (device-height : 812px) {#favApps.stacked {transform: translate(-50%, 530px);}} @media only screen and (device-width : 414px) and (device-height : 736px) {#favApps.stacked {transform: translate(-50%, 475px);}} @media only screen and (device-width : 375px) and (device-height : 667px) {#favApps.stacked {transform: translate(-50%, 425px);}} @media only screen and (device-width : 320px) and (device-height : 568px) {#favApps.stacked {transform: translate(-50%, 355px);}}", "disableStack");
    } else if(theStorage["disableMusic"] && theStorage["disableApp"]) {
        addStyle("#favApps.stacked {display: none;} #music.stacked {display: none;} #weather.stacked {transform: translate(-50%, 565px);} #timeContainer {bottom: 105px;} @media only screen and (device-width : 375px) and (device-height : 812px) {#weather.stacked {transform: translate(-50%, 500px);}} @media only screen and (device-width : 414px) and (device-height : 736px) {#weather.stacked {transform: translate(-50%, 450px);}} @media only screen and (device-width : 375px) and (device-height : 667px) {#weather.stacked {transform: translate(-50%, 395px);}} @media only screen and (device-width : 320px) and (device-height : 568px) {#weather.stacked {transform: translate(-50%, 325px);}}", "disableStack");
    }

    if(theStorage["disableApp"] && theStorage["disableWeather"] && theStorage["disableMusic"]) {
        addStyle("#favApps.stacked {display: none;} #music.stacked {display: none;} #weather.stacked {display: none;} #timeContainer {bottom: 50px;}", "disableStack");
    }

    if(theStorage["weatherBgColor"]) {
        addStyle("#weather.stacked {background-color:" + theStorage["weatherBgColor"] + "}", "weatherBgColorSettings");
    }

    if(theStorage["musicBgColor"]) {
        addStyle("#music.stacked {background-color:" + theStorage["musicBgColor"] + "}", "musicBgColorSettings");
    }

    if(theStorage["favAppsBgColor"]) {
        addStyle("#favApps.stacked {background-color:" + theStorage["favAppsBgColor"] + "}", "favAppsBgColorSettings");
    }
}

function createColorInput(params) {
    var label = createDOM({
            type: "div",
            className: 'settingsLabel',
            innerHTML: params.label
        }),
        customAccentColor = createDOM({
            type: "input",
            className: "customAccent",
            id: params.theColor
        });
    customAccentColor.type = "text";
    customAccentColor.value = theStorage[params.theColor] ? theStorage[params.theColor] : params.defaultColor;
    customAccentColor.style.backgroundColor = theStorage[params.theColor] ? theStorage[params.theColor] : params.defaultColor;
    var colorPicker = new CP(customAccentColor);

    colorPicker.on("change", function(r, g, b, a) {
        this.source.value = this.color(r, g, b, a);
        this.source.style.backgroundColor = this.color(r,g,b,a);
        theStorage.replaceValueInLS(params.theColor, this.color(r, g, b, a));
        checkSettings();
    });

    customAccentColor.addEventListener("keyup", function(even){
        event.preventDefault();

        if(even.keyCode === 13) {
            customAccentColor.style.backgroundColor = customAccentColor.value; 
            theStorage.replaceValueInLS(params.theColor, customAccentColor.value);
            checkSettings();
        }
    });

    customAccentColor.addEventListener("focus", moveUpForInput, false);
    customAccentColor.addEventListener("blur", resetMoveForInput, false);

    childAppender({
        div: params.el,
        children: [label, customAccentColor]
    });
}

function moveUpForInput(event) {
    var offsetFromCenter = event.target.getBoundingClientRect().top - ((screen.height / 2) - 40);
    if (Math.sign(offsetFromCenter) != -1) {
        doc.body.style.transition = '350ms ease';
        doc.body.style.webkitTransform = 'translateY(' + -offsetFromCenter + 'px)';
    }
}

function resetMoveForInput() {
    doc.body.style.webkitTransform = 'translateY(0px)';
}

function loadTime(systemData) {
    var twelveHour = systemData.isTwentyFourHourTimeEnabled ? false : true;
    theTime({
        amPm: twelveHour,
        addZero: true,
        done: function(time) {
            dayContainer.innerHTML = time.dayShortText() + ".";
            clockContainer.innerHTML = time.monthText() + " " + time.date() + ", " + time.hours() + ":" + time.minutes();
        }
    });
}

function loadWeather(weatherData) {
    weatherTemp.innerHTML = weatherData.now.temperature.current + "&deg" + weatherData.units.temperature;
    weatherIcon.style.backgroundImage = "url(contents/weatherIcons/" + weatherData.now.condition.code + ".svg)";
    
    weatherBody.innerHTML = "";
    for(let i = 0; i < 4; i++) {
        var weatherDay = createDOM({
                type: "div",
                id: "weatherDay" + i,
                className: "weatherDays dontTouch3",
                innerHTML: weatherData.daily[i].dayOfWeek
            }),
            weatherIcons = createDOM({
                type: "div",
                id: "weatherIcon" + i,
                className: "weatherIcons dontTouch3",
                styleImg: "contents/weatherIcons/" + weatherData.daily[i].condition.code + ".svg"
            }),
            weatherCondition = createDOM({
                type: "div",
                id: "weatherCondition" + i,
                className: "weatherCondition dontTouch3",
                innerHTML: weatherData.daily[i].temperature.maximum + "&deg" + weatherData.units.temperature + " / " + weatherData.daily[i].temperature.minimum + "&deg" + weatherData.units.temperature
            }),
            weatherHolder = createDOM({
                type: "div",
                className: "weatherHolder dontTouch2",
                appender: [weatherDay, weatherIcons, weatherCondition]
            });
        
        weatherBody.appendChild(weatherHolder);
    }
}

function loadMusic(musicData) {

    if(musicData.nowPlaying.artwork) {
        musicArtwork.style.backgroundImage = "url(" + musicData.nowPlaying.artwork + ")";
    } else {
        musicArtwork.style.backgroundImage = "url(contents/mediaIcons/no-artwork.svg)";
    }

    if(musicData.isPlaying) {
        play.style.backgroundImage = "url(contents/mediaIcons/pause.svg)";
        musicTrack.innerHTML = musicData.nowPlaying.title;
        musicArtist.innerHTML = musicData.nowPlaying.artist;
    } else {
        play.style.backgroundImage = "url(contents/mediaIcons/play.svg)";
        musicTrack.innerHTML = "No Media Playing";
        musicArtist.innerHTML = "";
    }

    handleTrackTimes(musicData.nowPlaying.elapsed, musicData.nowPlaying.length, false);
    handleScrobblePosition(musicData.nowPlaying.elapsed, musicData.nowPlaying.length);
    
}

function openStack(el) {
    el.style.transform = "translate(-50%, 0px)";
    el.classList.add("open");
}

function closeStack(el) {
    el.removeAttribute('style');
    el.classList.remove("open");
}

for(let i = 0; i < stacks.length; i++) {
    stacks[i].addEventListener("touchend", function(el){
        if(!touchMoved) {
            if(el.target.classList.contains("open")) {
                closeStack(el.target);
            } else if(el.target.classList.contains("dontTouch")) {
                if(el.target.parentElement.classList.contains("open")) {
                    closeStack(el.target.parentElement);
                } else {
                    openStack(el.target.parentElement);
                }
            } else if(el.target.classList.contains("dontTouch2")) {
                if(el.target.classList.contains("app")) {
                    el.stopPropagation();
                    if(!changingApp) {
                        api.apps.launchApplication(el.target.id);
                    }
                } else {
                    if(el.target.parentElement.parentElement.classList.contains("open")) {
                        closeStack(el.target.parentElement.parentElement);
                    } else {
                        openStack(el.target.parentElement.parentElement);
                    }
                }
            } else if(el.target.classList.contains("dontTouch3")) {
                if(!(el.target.classList.contains("musicButtons") || el.target.id == "slider")) {
                    if(el.target.parentElement.parentElement.parentElement.classList.contains("open")) {
                        closeStack(el.target.parentElement.parentElement.parentElement);
                    }
                } else {
                    el.stopPropagation();
                }
            } else {
                openStack(el.target);
            }
        }
        touchMoved = false;
    }, false);

    stacks[i].addEventListener("touchmove", () => touchMoved = true, false);
}

for(let i = 0; i < musicButtons.length; i++) {
    musicButtons[i].addEventListener("click", function(el) {
        switch(el.target.id) {
            case "prev": api.media.previousTrack();
                        break;

            case "play": api.media.togglePlayPause();
                        break;

            case "skip": api.media.nextTrack();
                        break;
        }
    })
}

function handleTrackTimes(elapsed, length, forceUpdate) {
    if (scrobbleIsDragging && !forceUpdate) return;

    const elapsedContent = length === 0 ? '--:--' : secondsToFormatted(elapsed);
    document.getElementById('elapsed').innerHTML = elapsedContent;

    const lengthContent = length === 0 ? '--:--' : secondsToFormatted(length);
    document.getElementById('length').innerHTML = lengthContent;

    document.getElementById('playbackTime').setAttribute('max', length);
    document.getElementById('playbackTime').value = elapsed;
}

function handleScrobblePosition(elapsed, length) {
    if (scrobbleIsDragging) return;

    const scrobble = document.getElementById('slider');
    scrobble.setAttribute('max', length);
    scrobble.value = elapsed;
}

function secondsToFormatted(seconds) {
    if (seconds === 0) return '0:00';

    const isNegative = seconds < 0;
    if (isNegative) return '0:00';

    seconds = Math.abs(seconds);
    const hours = Math.floor(seconds / 60 / 60);
    const minutes = Math.floor(seconds / 60) - (hours * 60);
    const secs = Math.floor(seconds - (minutes * 60) - (hours * 60 * 60));

    if (hours > 0) {
        return hours + ':' + (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
    } else {
        return minutes + ':' + (secs < 10 ? '0' : '') + secs;
    }
}

function onScrobbleUIChanged(input) {
    scrobbleIsDragging = true;
    handleTrackTimes(input, api.media.nowPlaying.length, true);
}

function onScrobbleChanged(input) {
    api.media.seekToPosition(input);
    handleTrackTimes(input, api.media.nowPlaying.length, true);

    scrobbleIsDragging = false;
}

function loadStorage() {
    theStorage.init({
        title: "stackedCardsStorage",
        extraStorage: {
            favApps: ["com.apple.mobilephone", "com.apple.MobileSMS", "com.apple.mobilesafari", "placeholder3", "placeholder4", "placeholder5", "placeholder6", "placeholder7", "placeholder8"]
        }
    });
}

function loadApps(apps) {
    favApps = theStorage.favApps;
    favAppsBody.innerHTML = "";
    for(let i = 0; i < favApps.length; i++) {
        var bundle = favApps[i],
            badge, icon,
            theApp = createDOM({
                type: "div",
                id: bundle,
                className: "app dontTouch2"
            });

        if(bundle == "placeholder" + i) {
            theApp.style.backgroundColor = 'white';
            theApp.setAttribute('name', 'Blank');
        } else {
            icon = apps.applicationForIdentifier(bundle).icon;
            theApp.setAttribute('name', apps.applicationForIdentifier(bundle).name);
            if(apps.applicationForIdentifier(bundle).badge > 0) {
                badge = createDOM({
                    type: "div",
                    className: "badge dontTouch3",
                    innerHTML: apps.applicationForIdentifier(bundle).badge
                });
                theApp.appendChild(badge);
            }
            theApp.style.backgroundImage = 'url(' + icon + ')';
        }

        favAppsBody.appendChild(theApp);
    }
}

function tapHoldOnIcon(element) {
    changingApp = true;
    target = element;
    thePrompter({
        type: "confirm",
        message: "Change app for " + element.getAttribute("name"),
        promptYesText: "Set App",
        promptNoText: "Cancel",
        promptYes: function() {
            changingApp = false;
            theDrawer({
                appChanger: true,
                container: document.getElementById("drawer"),
                title: "App Changer",
                done: function(theApp) {
                    theStorage.replaceAppFromLS('favApps', target.id, theApp);
                    loadApps(api.apps);
                }
            })
        },
        promptNo: function() {
            changingApp = false;
        }
    });   
}

menu.addEventListener("touchend", () => createSettings());