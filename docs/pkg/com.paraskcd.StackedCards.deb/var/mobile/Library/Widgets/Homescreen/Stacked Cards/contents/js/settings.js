function createSettings() {
    var settingsPanel = createDOM({
            type: "div",
            className: 'settingsPanel close',
        }),
        settingsTitle = createDOM({
            type: "div",
            className: 'settingsTitle',
            innerHTML: 'Settings',
        }),
        settingsDestroyer = createDOM({
            type: "div",
            className: 'settingsDestroyer',
            innerHTML: "❮",
        });
    
    settingsDestroyer.addEventListener("touchend", () => destroySettings(settingsPanel), false);
    
    var settingsHeader = createDOM({
            type: "div",
            className: 'settingsHeader',
            appender: [settingsTitle, settingsDestroyer]
        });

    var disableTimeHolder = createDOM({
            type: "div",
            className: "theSetting"
        }),
        disableWeatherHolder = createDOM({
            type: "div",
            className: 'theSetting'
        }),
        disableMusicHolder = createDOM({
            type: "div",
            className: "theSetting"
        }),
        disableFavAppsHolder = createDOM({
            type: "div",
            className: "theSetting"
        }),
        weatherColorHolder = createDOM({
            type: "div",
            className: "theSetting"
        }),
        musicColorHolder = createDOM({
            type: "div",
            className: "theSetting"
        }),
        favAppColorHolder = createDOM({
            type: "div",
            className: "theSetting"
        });

    createToggle({
        label: "Hide Date and Time",
        id: "hideTime",
        el: disableTimeHolder,
        bool: hideTime,
        info: "This will hide the Time and Date Container."
    });

    createToggle({
        label: "Disable Weather Stack",
        id: "disableWeather",
        el: disableWeatherHolder,
        bool: disableWeather,
        info: "This setting will disable Weather Stack."
    });

    createToggle({
        label: "Disable Music Stack",
        id: "disableMusic",
        el: disableMusicHolder,
        bool: disableMusic,
        info: "This setting will disable Music Stack."
    });

    createToggle({
        label: "Disable Fav App Stack",
        id: "disableApp",
        el: disableFavAppsHolder,
        bool: disableApp,
        info: "This setting will disable Fav App Stack."
    });

    createColorInput({
        label: "Weather Stack Color",
        el: weatherColorHolder,
        theColor: "weatherBgColor",
        defaultColor: weatherBgColor
    });

    createColorInput({
        label: "Music Stack Color",
        el: musicColorHolder,
        theColor: "musicBgColor",
        defaultColor: musicBgColor
    });

    createColorInput({
        label: "Fav Apps Stack Color",
        el: favAppColorHolder,
        theColor: "favAppsBgColor",
        defaultColor: favAppsBgColor
    });

    var settingsBody = createDOM({
            type: "div",
            className: 'settingsBody',
            appender: [disableTimeHolder, disableWeatherHolder, disableMusicHolder, disableFavAppsHolder, weatherColorHolder, musicColorHolder, favAppColorHolder]
        });

    childAppender({
        div: settingsPanel,
        children: [settingsHeader, settingsBody]
    });

    doc.body.appendChild(settingsPanel);
    setTimeout(function(){
        requestAnimationFrame(() => {
            settingsPanel.classList.remove("close");
        });
    }, 150);        
}