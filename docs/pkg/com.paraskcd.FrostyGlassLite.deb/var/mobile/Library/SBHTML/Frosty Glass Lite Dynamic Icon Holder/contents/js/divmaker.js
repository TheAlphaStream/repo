 document.addEventListener('DOMContentLoaded', function() {

   let x = columns;

	for(i = 0; i < x; i++){
		var div = document.createElement('div');
		var top = (i * distanceBetween) + 5;
		div.id = "iconHolder" + i;
		div.className = "container";
		div.style.top = top + "vh";
		div.style.height = heightSize + "vh";
		div.style.width = widthSize + "vh";
		document.getElementById('pageContainer').appendChild(div);
	}
	
});