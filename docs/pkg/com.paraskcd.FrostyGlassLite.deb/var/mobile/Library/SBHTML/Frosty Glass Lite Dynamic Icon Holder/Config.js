var columns = "6"; // Add the amount of glass you want to be created as columns. Default 6.
var heightSize = "5"; // Add a number specifying the height of the Glass. Default 5.
var widthSize = "34"; // Add a number specifying the width of the Glass. Default 34.
var distanceBetween = "9"; // Add a number specifying the distance between the Columns, Recommended from 9 to 15. Default 10.
