var doc = document,
	dockHolder = doc.getElementById("dockHolder");

function checkSettings() {
	dockHolder.style.bottom = verticalPosition + "vh";
	dockHolder.style.left = horizontalPosition + "vh";
	dockHolder.style.height = heightSize + "vh";
	dockHolder.style.width = widthSize + "vh";
}

checkSettings();