var heightSize = "5"; //Write a number to change the height of the Dock holder, recommended heights are from 5 to 10. Default 5.
var widthSize = "34"; //Write a number to change the width of the Dock Holder, recommended widths are from 30 to 37. Default 34.
var verticalPosition = "1.5"; //Write a number to change the position vertically of the Dock Holder, the more the number, the more it goes up. Default 20.
var horizontalPosition = "5"; //Write a number to change the position horizontally of the Dock Holder, the more the number, the more it goes to the left. Default 5.