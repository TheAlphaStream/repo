//Script by @ParasKCD
window.requestAnimFrame = (function () {
    return window.requestAnimationFrame || window.webkitRequestAnimationFrame;
}());

function theTime(opts) {
	var showTime = function() {
		var language = window.navigator.language.split('-')[0];
		var d = new Date(),
		hourText = (opts.amPm === false) ? ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty One", "Twenty Two", "Twenty Three", "Twenty Four"] : ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"],
		minuteoneText = ["o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty"],
		minutetwoText = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", ""],
		addZeroToTime = function(i) {
			if(i < 10) {
				i = "0" + i;
			}
			return i;
		},
		timeFuncs = {
			hours: function() {
				var hour = (opts.amPm === true) ? (d.getHours() + 11) % 12 + 1 : d.getHours();
				hour = (opts.addZero === true) ? addZeroToTime(hour) : hour;
				return hour;
			},
			minutes: function() {
				var minute = d.getMinutes();
				minute = (opts.addZero === true) ? addZeroToTime(minute) : minute;
				return minute;
			},
			seconds: function() {
				var seconds = d.getSeconds();
				seconds = (opts.addZero === true) ? addZeroToTime(seconds) : seconds;
				return seconds;
			},
			hoursText: function() {
				var textHours = hourText[d.getHours()];
				return textHours;
			},
			minutesText: function() {
    			var textMinuteOne = minuteoneText[d.getMinutes()],
    				textMinuteTwo = minutetwoText[d.getMinutes()];
    			return textMinuteOne + " " + textMinuteTwo;
			},
			minuteOneText: function() {
				return minuteoneText[d.getMinutes()];
			},
			minuteTwoText: function() {
				return minutetwoText[d.getMinutes()];
			},
			monthText: function() {
				return months[d.getMonth()];
			},
			monthShortText: function() {
				return monthsShort[d.getMonth()];
			},
			dayText: function() {
				return days[d.getDay()];
			},
			dayShortText: function() {
				return daysShort[d.getDay()];
			},
			dateText: function () {
                var textdate = ["First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth", "Eleventh", "Twelfth", "Thirteenth", "Fourteenth", "Fifteenth", "Sixteenth", "Seventeenth", "Eightheenth", "Nineteenth", "Twentyith", "TwentyFirst", "TwentySecond", "TwentyThird", 'TwentyFourth', "TwentyFifth", "TwentySixth", "TwentySeventh", "TwentyEight", "TwentyNinth", "Thirtyith", "ThirtyFirst"];
                return textdate[this.date() - 1];
            },
			date: function() {
				return d.getDate();
			},
			nth: function(d) {
				if (d > 3 && d < 21) {
                    return 'th';
                }
                switch (d % 10) {
                case 1:
                    return "st";
                case 2:
                    return "nd";
                case 3:
                    return "rd";
                default:
                    return "th";
                }
			},
			dateNth: function() {
				return d.getDate() + this.nth(Number(d.getDate));
			},
			am: function() {
				var am = (opts.amPm === true) ? ((d.getHours() > 11) ? "pm" : "am") : "";
				return am;
			}
		}
		opts.done(timeFuncs);
		setTimeout(function () {
            window.requestAnimFrame(showTime);
        }, 1000);
	}
	showTime();
}