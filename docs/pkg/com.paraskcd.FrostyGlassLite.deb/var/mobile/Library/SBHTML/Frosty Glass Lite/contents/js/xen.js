function mainUpdate(type) {
	var artworkPreload;
	
	if(type == "weather") {
		document.getElementById("weatherIcon").style.backgroundImage = "url(contents/weather/" + weather.conditionCode + ".png)";
		document.getElementById('weatherTemp').innerHTML = '<span id = "theTemperature">' + weather.temperature + '&deg</span>';
		document.getElementById("weatherCondition").innerHTML = "<span id='naturalCondition'>In " + weather.address.city + ", it is " + weather.naturalCondition + "</span>";
	}

	if (type == 'music') {
        if (isplaying) {
            document.getElementById('play').style.backgroundImage = "url(contents/icons/pause.png)";
            document.getElementById('musicTitle').innerHTML = title;
            document.getElementById('musicArtist').innerHTML = ' - ' + artist;
            artworkPreload = new Image();
            artworkPreload.onload = function() {
                
                document.getElementById("musicArtwork").style.backgroundImage = "url(" + this.src + ")";
            };
           
            artworkPreload.src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
        } else {
            document.getElementById('play').style.backgroundImage = "url(contents/icons/play.png)";
        }
    }
}

document.getElementById("play").addEventListener('touchstart', function() {
    window.location = 'xeninfo:playpause';
});
document.getElementById("skip").addEventListener('touchstart', function() {
    window.location = 'xeninfo:nexttrack';
});
document.getElementById("prev").addEventListener('touchstart', function() {
    window.location = 'xeninfo:prevtrack';
});