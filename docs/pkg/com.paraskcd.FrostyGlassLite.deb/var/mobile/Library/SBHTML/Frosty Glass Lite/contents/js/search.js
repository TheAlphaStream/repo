document.getElementById("search").addEventListener("keyup", function(even){
    event.preventDefault();

    if(even.keyCode === 13) {
        document.getElementById("button").click();
    }
});

function search() {
    window.location = 'xeninfo:openurl:google.com/search?q=' + document.getElementById("search").value + '';
}

document.getElementById("search").addEventListener("keyup", function(even){
    event.preventDefault();

    if(even.keyCode === 13) {
        document.getElementById("search").value = "";
    }
});