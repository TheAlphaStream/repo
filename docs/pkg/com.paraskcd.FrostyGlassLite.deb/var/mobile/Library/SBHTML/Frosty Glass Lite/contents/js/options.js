var doc = document,
	theTime = doc.getElementById('theTime'),
	theDay = doc.getElementById('theDay'),
	theDate = doc.getElementById('theDate'),
	searchContainer = doc.getElementById('glass1'),
	weatherContainer = doc.getElementById('glass2'),
	musicContainer = doc.getElementById('switch');

function checkSettings() {

	if(hideTime){
		theTime.style.display = "none";
	}

	if(hideDay) {
		theDay.style.display = "none";
	}

	if(hideDate) {
		theDate.style.display = "none";
	}

	if(hideSearchBar) {
		searchContainer.style.display = "none";
		weatherContainer.style.top = "41vh";
		doc.getElementById('musicContainer').style.top = "42vh";
		musicContainer.style.top = "58vh";
	}

	if(hideWeather) {
		weatherContainer.style.display = "none";
	}

	if(hideMusic) {
		musicContainer.style.display = "none";
	}

}

checkSettings();