var container = $("#glass2"),
	weatherContainer = $("#weatherContainer"),
	musicContainer = $("#musicContainer");

$(document).ready(function(){
    $('input[type="checkbox"]').click(function(){
        if($(this).prop("checked") == true){
            container.removeClass('weatherOpen');
			weatherContainer.hide("fade", 350);
			musicContainer.show("fade", 350);
        }
        else if($(this).prop("checked") == false){
            container.addClass('weatherOpen');
			musicContainer.hide("fade", 350);
			weatherContainer.show("fade", 350);
        }
    });
});