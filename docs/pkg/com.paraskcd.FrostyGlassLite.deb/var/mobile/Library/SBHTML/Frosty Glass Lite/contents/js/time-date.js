var twofour = (twentyfour) ? true : false;
theTime({
    amPm: twofour,
    addZero: true,
    done: function(time) {
        document.getElementById('theTime').innerHTML = '<span id = "time">' + time.hours() + ':' + time.minutes() + '</span>';
        document.getElementById('theDay').innerHTML = '<span id = "day">' + time.dayText() + '</span>';
        document.getElementById('theDate').innerHTML = "<span id='dateInfo'>" + time.monthText() + " " + time.date() + "</span>";
    }
});