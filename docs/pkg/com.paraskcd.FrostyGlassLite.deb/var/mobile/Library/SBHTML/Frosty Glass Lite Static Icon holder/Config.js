var heightSize = "55"; // Write a number to change the height of the Icon holder, recommended heights are from 20 to 70. Default 55.
var widthSize = "34"; // Write a number to change the width of the Icon Holder, recommended widths are from 30 to 37. Default 34.
var verticalPosition = "20"; // Write a number to change the position vertically of the Icon Holder, the more the number, the more it goes down. Default 20.
var horizontalPosition = "5"; // Write a number to change the position horizontally of the Icon Holder, the more the number, the more it goes to the left. Default 5.
