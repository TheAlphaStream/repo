var doc = document,
	iconHolder = doc.getElementById("iconHolder");

function checkSettings() {
	iconHolder.style.top = verticalPosition + "vh";
	iconHolder.style.left = horizontalPosition + "vh";
	iconHolder.style.height = heightSize + "vh";
	iconHolder.style.width = widthSize + "vh";
}

checkSettings();