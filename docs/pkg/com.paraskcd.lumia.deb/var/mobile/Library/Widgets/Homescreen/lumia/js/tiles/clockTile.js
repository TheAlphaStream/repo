var clockTileMaker = {
    clockData: function() {
        const content = `<div id="time"></div>
                        <span class="branding-bar">${api.apps.applicationForIdentifier("com.apple.mobiletimer").name}</span>`;
        time.init({
            refresh: 1000, // How much time to let time refresh in ms (Number)
            twentyfour: config.twentyfourhour, // 24hour or not (Boolean)
            callback: function(time) { //Check funcs to get your desired Values
                if(document.getElementById("time")) document.getElementById("time").innerHTML = time.hour() + ":" + time.minute() + time.ampm();
                if(document.getElementById("date")) document.getElementById("date").innerHTML = time.date() + " " + time.monthText();
            }
        });
        return content;
    },
    init: function(params) {
        let content = this.clockData();
        let color = params.color === "bg-custom" ? "bg-custom bg-blur" : params.color + " bg-blur";
        if(!document.getElementById("com.apple.mobiletimer")) {
            const htmlString = `<div name="${api.apps.applicationForIdentifier("com.apple.mobiletimer").name}" id="com.apple.mobiletimer" data-size="${params.tileSize}" data-role="tile" class="leTile leClockTile ${color}">
                                ${content}
                            </div>`;
            loadWidget.startMenu.innerHTML += htmlString;
        } else {
            document.getElementById("com.apple.mobiletimer").innerHTML = content;
        }
    }
}