var settingsMaker = {
    styles: [],
    addStyle: function(params) {
        let element, node;
        if(params.id) {
            if(document.getElementById(params.id)) {
                element = document.getElementById(params.id);
                document.body.removeChild(element);
            }
        }
        node = domMaker.init({
            type: "style",
            id: params.id,
            innerHTML: params.str
        });
        return node;
    },
    appendToBody: function() {
        domMaker.domAppender({
            div: document.body,
            children: this.styles
        })
    },
    init: function() {
        this.styles.push(this.addStyle({
            id: "mainStyling",
            str: `
                html, body {
                    color: ${config.textColor};
                }
                .bg-custom, #bg-custom, div#applications div#drawerSearchContainer {
                    background-color: ${config.customColor};
                }
                .bg-blur {
                    backdrop-filter: blur(${config.blurIntensity}px)!important;
                    -webkit-backdrop-filter: blur(${config.blurIntensity}px)!important;
                }
                .menuWindow, .menuWindow .menuButton, .tile-small, .tile-medium, .tile-wide, .tile-large, .tile-small:hover, .tile-medium:hover, .tile-wide:hover, .tile-large:hover, .tile-app:hover, div#applications div#drawerSearchContainer, div#allApps div.alphabeticalOrder {
                    border-radius: ${Math.ceil(config.borderRadius)}px!important;
                }
                `
        }));
        if(config.colorOpacity) {
            this.styles.push(this.addStyle({
                id: "mainStyling2",
                str: `
                    :root {
                        --lime : rgba(164, 196, 0, ${config.colorOpacity});
                        --green: rgba(96, 169, 23, ${config.colorOpacity});
                        --emerald: rgba(0, 138, 0, ${config.colorOpacity});
                        --blue: rgba(0, 175, 240, ${config.colorOpacity});
                        --teal: rgba(0, 171, 169, ${config.colorOpacity});
                        --cyan: rgba(27, 160, 226, ${config.colorOpacity});
                        --cobalt: rgba(0, 80, 239, ${config.colorOpacity});
                        --indigo: rgba(106, 0, 255, ${config.colorOpacity});
                        --violet: rgba(170, 0, 255, ${config.colorOpacity});
                        --pink: rgba(220, 79, 173, ${config.colorOpacity});
                        --magenta: rgba(216, 0, 115, ${config.colorOpacity});
                        --crimson: rgba(162, 0, 37, ${config.colorOpacity});
                        --red: rgba(206, 53, 44, ${config.colorOpacity});
                        --orange: rgba(250, 104, 0, ${config.colorOpacity});
                        --amber: rgba(240, 163, 10, ${config.colorOpacity});
                        --yellow: rgba(255, 240, 0, ${config.colorOpacity});
                        --brown: rgba(130, 90, 44, ${config.colorOpacity});
                        --olive: rgba(109, 135, 100, ${config.colorOpacity});
                        --steel: rgba(100, 118, 135, ${config.colorOpacity});
                        --mauve: rgba(118, 96, 138, ${config.colorOpacity});
                        --taupe: rgba(135, 121, 78, ${config.colorOpacity});
                        --gray: rgba(190, 190, 190, ${config.colorOpacity});
                    } `
            }));
        }
        if(config.realWindowsExp) {
            this.styles.push(this.addStyle({
                id: "realWindowsExpStyling",
                str: `
                    html, body {
                        background-color: #000;
                    }
                    div#applications div#drawerSearchContainer {
                        background-color: transparent;
                        border: 1px solid #fff;
                    }
                    .bg-blur {
                        backdrop-filter: blur(0px)!important;
                        -webkit-backdrop-filter: blur(0px)!important;
                    }
                    .tile-small, .tile-medium, .tile-wide, .tile-large, .tile-small:hover, .tile-medium:hover, .tile-wide:hover, .tile-large:hover, .tile-app:hover, div#applications div#drawerSearchContainer, div#allApps div.alphabeticalOrder {
                        border-radius: 0px!important;
                    }
                    `
            }));
        }
        if(config.enableNavbarBgColor) {
            this.styles.push(this.addStyle({
                id: "enableNavBarBgColorStyling",
                str: `
                    div#navBar{
                        background-color: ${config.navBgColor};
                    }
                    `
            }));
        }
        if(config.enableWindowsCustomColor) {
            this.styles.push(this.addStyle({
                id: "enableWindowsCustomColor",
                str: `
                    div#navBar{
                        color: ${config.windowsIconColor};
                    }
                    `
            }));
        }
        if(config.disableBorders) {
            this.styles.push(this.addStyle({
                id: "disableBorders",
                str: `
                    .tile-small,
                    .tile-medium,
                    .tile-wide,
                    .tile-large,
                    .tile-app {
                        box-shadow: unset;
                    }
                    `
            }))
        }
        if(config.hideLabels) {
            this.styles.push(this.addStyle({
                id: "hideLabels",
                str: `
                    .branding-bar {
                        display: none!important;
                    }
                    `
            }));
        }
        this.appendToBody();
    }
}

settingsMaker.init();