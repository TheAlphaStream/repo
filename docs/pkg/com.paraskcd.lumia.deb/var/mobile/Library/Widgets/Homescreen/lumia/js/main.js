var globalParams = {
    mifWeather: [
        "mif-lines", //0
        "mif-lightning3", //1
        "mif-lightning3", //2
        "mif-lightning3", //3
        "mif-lightning3", //4
        "mif-snowy", //5
        "mif-snowy3", //6
        "mif-snowy3", //7
        "mif-rainy", //8
        "mif-rainy", //9
        "mif-rainy2", //10
        "mif-rainy2", //11
        "mif-rainy2", //12
        "mif-snowy3", //13
        "mif-snowy3", //14
        "mif-snowy3", //15
        "mif-snowy2", //16
        "mif-weather4", //17
        "mif-weather4", //18
        "mif-wind", //19
        "mif-lines", //20
        "mif-weather3", //21
        "mif-weather3", //22
        "mif-wind", //23
        "mif-wind", //24
        "mif-showflake", //25
        "mif-cloudy2", //26
        "mif-cloud2", //27
        "mif-cloudy", //28
        "mif-cloud2", //29
        "mif-cloudy", //30
        "mif-moon", //31
        "mif-sun", //32
        "mif-cloud2", //33
        "mif-cloudy", //34
        "mif-weather5", //35
        "mif-thermometer", //36
        "mif-lightning3", //37
        "mif-lightning3", //38
        "mif-rainy2", //39
        "mif-rainy2", //40
        "mif-snowy3", //41
        "mif-snowy3", //42
        "mif-snowy3", //43
        "mif-none", //44
        "mif-thermometer", //45
        "mif-lightning3", //46
        "mif-lightning3", //47
    ],
    mifIcons: {
        "com.apple.calculator": "mif-calculator",
        "com.apple.camera": "mif-camera",
        "com.apple.MobileAddressBook": "mif-contacts-dialer",
        "com.apple.DocumentsApp": "mif-folder",
        "com.apple.Home": "mif-home",
        "com.apple.mobilemail": "mif-mail",
        "com.apple.Maps": "mif-map",
        "com.apple.MobileSMS": "mif-bubbles",
        "com.apple.Music": "mif-music",
        "com.apple.news": "mif-news",
        "com.apple.mobilenotes": "mif-note",
        "com.apple.mobilephone": "mif-phone",
        "com.apple.mobileslideshow": "mif-images",
        "com.apple.mobilesafari": "mif-safari",
        "com.amazon.AmazonIN": "mif-amazon",
        "com.amazon.Amazon": "mif-amazon",
        "com.apple.iBooks": "mif-books",
        "com.apple.mobilecal": "mif-calendar",
        "com.apple.compass": "mif-compass2",
        "com.getdropbox.Dropbox": "mif-dropbox",
        "com.facebook.Facebook": "mif-facebook",
        "com.tigisoftware.Filza": "mif-finder",
        "com.github.stormbreaker.prod": "mif-github",
        "com.google.GoogleMobile": "mif-google",
        "com.google.Maps": "mif-map2",
        "com.burbn.instagram": "mif-instagram",
        "com.linkedin.LinkedIn": "mif-linkedin",
        "com.yourcompany.PPClient": "mif-paypal",
        "com.reddit.Reddit": "mif-reddit",
        "tv.twitch": "mif-twitch",
        "com.atebits.Tweetie2": "mif-twitter",
        "net.whatsapp.WhatsAppSMB": "mif-whatsapp",
        "net.whatsapp.WhatsApp": "mif-whatsapp",
        "com.apple.mobiletimer": "mif-alarm"
    }
};

var loadWidget = {
    startMenu: "",
    appDrawer: "",
    loadStartScreen: function() {
        startScreenMaker.init(api.apps, api.media);
    },
    loadAppDrawer: function() {
        appDrawerMaker.init();
    },
    init: function(params) {
        this.startMenu = params.startMenu;
        this.appDrawer = params.appDrawer;
        params.startButton.addEventListener("touchend", (e) => {
            window.requestAnimationFrame(() => {
                let pageContainer = document.getElementById("pageContainer");
                if(pageContainer.scrollLeft > 0) {
                    pageContainer.scroll({
                        left: 0,
                        behavior: "smooth"
                    });
                } 
                if(pageContainer.scrollLeft < 50) {
                    pageContainer.scroll({
                        left: 500,
                        behavior: "smooth"
                    });
                }
                appDrawerMaker.checkIfMenuExists();
                e.target.style.transition = "100ms ease-in-out";
                e.target.style.color = "#1ba1e2";
                e.target.style.transform = "scale(1.5)";
                setTimeout(() => {
                    e.target.style.color = null
                    e.target.style.transform = null;
                }, 250);
            });
        });
        localstore.init({
            storageName: "metroUI",
            callback: loadWidget.loadStartScreen
        })
        this.loadAppDrawer();
        let allApps = document.getElementById("allApps");
        allApps.addEventListener("touchend", (el) => {
            if(!appDrawerMaker.invokeMenu && !appDrawerMaker.movedWhilePressing) {
                if(el.target.className === "alphabeticalOrder") {
                    appDrawerMaker.alphabetMaker();
                } else {
                    appDrawerMaker.openApp(el.target.id, () => {
                        appDrawerMaker.isSearching = false;
                        document.getElementById("drawerSearchTextField").value = "";
                        el.target.parentElement.innerHTML = appDrawerMaker.displayApps(appDrawerMaker.allApplications);
                    });
                }
            }
            if(el.target.className === 'application') {
                setTimeout(function(){
                    appDrawerMaker.animateIcon(false, el.target.id);
                }, 100);
            }
            appDrawerMaker.movedWhilePressing = false;
        });
        allApps.addEventListener('touchstart', appDrawerMaker.animateApp, false);
        allApps.addEventListener('touchmove', () => appDrawerMaker.movedWhilePressing = true, false);
        touchhold.init({
            time: 400,
            element: allApps,
            callback: function(el) {
                appDrawerMaker.tapHoldOnIcon(el);
            },
        });
        loadWidget.startMenu.addEventListener("click", (e) => startScreenMaker.launchApp(e.target.id));
        touchhold.init({
            time: 500,
            element: loadWidget.startMenu,
            callback: function(el) {
                startScreenMaker.tapHoldOnIcon(el);
            },
        });
    }
}