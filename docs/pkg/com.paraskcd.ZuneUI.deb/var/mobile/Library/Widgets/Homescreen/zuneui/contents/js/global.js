//////////////////////////////////////////////////////////////////////////////
//VARIABLES
//////////////////////////////////////////////////////////////////////////////

var doc = document;

var touchMoved = false;
    changingApp = false;
    target = null;

var weathericons = ["&#xf056;", "&#xf00e;", "&#xf073;", "&#xf01e;", "&#xf01e;", "&#xf017;", "&#xf017;", "&#xf017;", "&#xf015;", "&#xf01a;", "&#xf015;", "&#xf01a;", "&#xf01a;", "&#xf01b;", "&#xf00a;", "&#xf064;", "&#xf01b;", "&#xf015;", "&#xf017;", "&#xf063;", "&#xf014;", "&#xf021;", "&#xf062;", "&#xf050;", "&#xf050;", "&#xf076;", "&#xf013;", "&#xf031;", "&#xf002;", "&#xf031;", "&#xf002;", "&#xf02e;", "&#xf00d;", "&#xf083;", "&#xf00c;", "&#xf017;", "&#xf072;", "&#xf00e;", "&#xf00e;", "&#xf00e;", "&#xf01a;", "&#xf064;", "&#xf01b;", "&#xf064;", "&#xf00c;", "&#xf00e;", "&#xf01b;", "&#xf00e;", "&#xf077;"];

var mainContainer = doc.getElementById("mainContainer"),
    time = doc.getElementById("time"),
    date = doc.getElementById("date"),
    weather = doc.getElementById("weather"),
    batteryIcon = doc.getElementById("batteryIcon"),
    batteryPercent = doc.getElementById("batteryPercent"),
    signalIcon = doc.getElementById("signalIcon"),
    signalType = doc.getElementById("signalType"),
    wifiIcon = doc.getElementById("wifiIcon"),
    menuButton = doc.getElementById("menuButton"),
    menuContainer = doc.getElementById("menuContainer"),
    backButton = doc.getElementById("backButton"),
    pageContainer = doc.getElementById("pageContainer"),
    favSocialApps = doc.getElementById("favSocialApps"),
    musicTitle = doc.getElementById("musicTitle"),
    musicArtist = doc.getElementById("musicArtist"),
    musicArtwork = doc.getElementById("musicArtwork"),
    play = doc.getElementById("play"),
    weatherTemp = doc.getElementById("weatherTemp"),
    weatherIcon = doc.getElementById("weatherIcon"),
    weatherBody = doc.getElementById("weatherBody");

var menuItem = doc.getElementsByClassName("menu"),
    theBackButton = doc.getElementsByClassName("theBackButton"),
    musicButtons = doc.getElementsByClassName("musicButtons");

//////////////////////////////////////////////////////////////////////////////
//FUNCTIONS
//////////////////////////////////////////////////////////////////////////////

function createDOM(params) {
    var element = doc.createElement(params.type);
    if(params.id) {
        element.id = params.id;
    }
    if(params.className) {
        element.className = params.className;
    }
    if(params.innerHTML) {
        element.innerHTML = params.innerHTML;
    }
    if(params.styleImg) {
        element.style.backgroundImage = "url(" + params.styleImg + ")";
    }
    if(params.appender) {
        for(let i = 0; i < params.appender.length; i++) {
            element.appendChild(params.appender[i]);
        }
    }
    return element;
}

function loadTime(systemData) {
    var twelveHour = systemData.isTwentyFourHourTimeEnabled ? false : true;
    theTime({
        amPm: twelveHour,
        addZero: true,
        done: function(timeObj) {
            time.innerHTML = timeObj.hours() + ":" + timeObj.minutes();
            date.innerHTML = timeObj.monthText() + " " + timeObj.date();
        }
    });
}

function checkBattery(resourceData) {
    var battlevel = Math.ceil((resourceData.battery.percentage) / 10) * 10;
    batteryPercent.innerHTML = resourceData.battery.percentage + "%";
    batteryIcon.style.backgroundImage = "url(contents/battery/" + battlevel + ".png)";
}

function loadWeather(weatherData) {
    weather.innerHTML = "In " + weatherData.metadata.address.city + " it's " + weatherData.now.condition.narrative;

    weatherTemp.innerHTML = weatherData.now.temperature.current + "&deg" + weatherData.units.temperature;
    weatherIcon.innerHTML = weathericons[weatherData.now.condition.code];

    weatherBody.innerHTML = "";
    for(let i = 0; i < 7; i++) {
        var weatherDay = createDOM({
                type: "div",
                id: "weatherDay" + i,
                className: "weatherDays",
                innerHTML: weatherData.daily[i].dayOfWeek
            }),
            weatherIcons = createDOM({
                type: "div",
                id: "weatherIcon" + i,
                className: "weatherIcons",
                innerHTML: weathericons[weatherData.daily[i].condition.code]
            }),
            weatherCondition = createDOM({
                type: "div",
                id: "weatherCondition" + i,
                className: "weatherCondition",
                innerHTML: weatherData.daily[i].temperature.maximum + "&deg" + weatherData.units.temperature + " / " + weatherData.daily[i].temperature.minimum + "&deg" + weatherData.units.temperature
            }),
            weatherHolder = createDOM({
                type: "div",
                className: "weatherHolder",
                appender: [weatherDay, weatherIcons, weatherCondition]
            });

        weatherBody.appendChild(weatherHolder);
    }
}

function openCloseContainer(whatPressed) {
    switch(whatPressed) {
        case "menuButton":
            menuContainer.classList.add("open");
            pageContainer.classList.add("menuOpened");
            break;

        case "backButton":
            mainContainer.classList.remove("menuOpened");
            pageContainer.classList.remove("menuOpened");
            mainContainer.classList.remove("containerOpened");
            menuContainer.classList.remove("containerOpened");
            break;

        case "menuItem":
            mainContainer.classList.add("containerOpened");
            menuContainer.classList.add("containerOpened");
            break;

        case "containerBackButton":
            mainContainer.classList.remove("containerOpened");
            menuContainer.classList.remove("containerOpened");
            break;
    }
}

function loadStorage() {
    theStorage.init({
        title: "zuneUIStorage2",
        extraStorage: {
            favApps: ["com.apple.Preferences", "com.apple.MobileSMS", "com.apple.mobilesafari", "placeholder3", "placeholder4", "placeholder5", "placeholder6", "placeholder7"]
        }
    });
}

function loadApps(apps) {
    favApps = theStorage.favApps;
    favSocialApps.innerHTML = "";
    for(let i = 0; i < favApps.length; i++) {
        var bundle = favApps[i],
            badge, icon,
            theApp = createDOM({
                type: "div",
                id: bundle,
                className: "app"
            });

        if(bundle == "placeholder" + i) {
            theApp.style.backgroundColor = 'white';
            theApp.setAttribute('name', 'Blank');
        } else {
            icon = apps.applicationForIdentifier(bundle).icon;
            theApp.setAttribute('name', apps.applicationForIdentifier(bundle).name);
            if(apps.applicationForIdentifier(bundle).badge > 0) {
                badge = createDOM({
                    type: "div",
                    className: "badge",
                    innerHTML: apps.applicationForIdentifier(bundle).badge
                });
                theApp.appendChild(badge);
            }
            theApp.style.backgroundImage = 'url(' + icon + ')';
        }

        favSocialApps.appendChild(theApp);
    }
}

function tapHoldOnIcon(element) {
    changingApp = true;
    target = element;
    thePrompter({
        type: "confirm",
        message: "Change app for " + element.getAttribute("name"),
        promptYesText: "Set App",
        promptNoText: "Cancel",
        promptYes: function() {
            changingApp = false;
            theDrawer({
                appChanger: true,
                container: document.getElementById("drawer"),
                title: "App Changer",
                done: function(theApp) {
                    theStorage.replaceAppFromLS('favApps', target.id, theApp);
                    loadApps(api.apps);
                }
            })
        },
        promptNo: function() {
            changingApp = false;
        }
    });   
}

function loadMusic(musicData) {
    if(musicData.nowPlaying.artwork) {
        musicArtwork.style.backgroundImage = "url(" + musicData.nowPlaying.artwork + ")";
    } else {
        musicArtwork.style.backgroundImage = "url(contents/mediaIcons/no-artwork.svg)";
    }

    if(musicData.isPlaying) {
        play.style.backgroundImage = "url(contents/mediaIcons/pause.svg)";
        musicTitle.innerHTML = musicData.nowPlaying.title;
        musicArtist.innerHTML = musicData.nowPlaying.artist;
    } else {
        play.style.backgroundImage = "url(contents/mediaIcons/play.svg)";
        musicTitle.innerHTML = "No Media Playing";
        musicArtist.innerHTML = ".";
    }
}

menuButton.addEventListener("touchend", function() {
    mainContainer.classList.add("menuOpened");
    setTimeout(function() {
        openCloseContainer("menuButton");
    }, 50);
});

backButton.addEventListener("touchend", function() {
    menuContainer.classList.remove("open");
    setTimeout(function() {
        openCloseContainer("backButton");
    }, 50);
});

favSocialApps.addEventListener("touchend", function(el) {
    if(el.target.classList.contains("app")) {
        if(!changingApp && !touchMoved) {
            api.apps.launchApplication(el.target.id);
        }
        touchMoved = false;
    }
});

favSocialApps.addEventListener("touchmove", () => touchMoved = true);

for(let i = 0; i < musicButtons.length; i++) {
    musicButtons[i].addEventListener("click", function(el) {
        switch(el.target.id) {
            case "prev": api.media.previousTrack();
                        break;

            case "play": api.media.togglePlayPause();
                        break;

            case "skip": api.media.nextTrack();
                        break;
        }
    })
}

for(let i = 0; i < theBackButton.length; i++) {
    theBackButton[i].addEventListener("click", function(el) {
        switch(el.target.id) {
            case "socialBackButton":
                doc.getElementById("socialContainer").classList.remove("openContainer");
                doc.getElementById("socialContainer").style.pointerEvents = "none";
                break;

            case "musicBackButton":
                doc.getElementById("musicContainer").classList.remove("openContainer");
                doc.getElementById("musicContainer").style.pointerEvents = "none";
                break;

            case "weatherBackButton":
                doc.getElementById("weatherContainer").classList.remove("openContainer");
                doc.getElementById("weatherContainer").style.pointerEvents = "none";
                break;
        }
        openCloseContainer("containerBackButton");
    });
}

for(let i = 0; i < menuItem.length; i++) {
    menuItem[i].addEventListener("click", function(el) {
        setTimeout(function() {
            if(el.target.id != "applicationsMenu") {
                openCloseContainer("menuItem");
                switch(el.target.id) {
                    case "socialMenu":
                        doc.getElementById("socialContainer").style.pointerEvents = "all";
                        setTimeout(function(){
                            doc.getElementById("socialContainer").classList.add("openContainer");
                        }, 100);
                        break;
        
                    case "musicMenu":
                        doc.getElementById("musicContainer").style.pointerEvents = "all";
                        setTimeout(function(){
                            doc.getElementById("musicContainer").classList.add("openContainer");
                        }, 100);
                        break; 
        
                    case "weatherMenu":
                        doc.getElementById("weatherContainer").style.pointerEvents = "all";
                        setTimeout(function(){
                            doc.getElementById("weatherContainer").classList.add("openContainer");
                        }, 100);
                        break;
                }
            }
            
        }, 100);
    });
}