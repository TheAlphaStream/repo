(function() {
    //checkBattery(api.resources);
    loadTime(api.system);
    loadWeather(api.weather);
    loadMusic(api.media);
    loadStorage();
    //loadApps(api.apps);
    
    taphold({
        time: 400,
        element: doc.getElementById("favSocialApps"),
        action: function(element) {
            console.log(changingApp);
            tapHoldOnIcon(element);
        },
        passTarget: true
    });
    theDrawer({
        appChanger: false, //States if you want to use it as an appChanger or not.
        container: document.getElementById("drawer"), //States the container (div) you want the Drawer to attach to.
        title: "Applications", //States the title that can be put above the container.
        idSuffix: "apps", //States what suffix will be used in the Id of each app.
        addEvent: document.getElementById("applicationsMenu") //States the container to attach an eventListener to.
    });

    
}());


api.resources.observeData(function(resourcesData) {
    var battlevel = Math.ceil((resourcesData.battery.percentage) / 10) * 10;
    document.getElementById("batteryPercent").innerHTML = resourcesData.battery.percentage + "%";
    document.getElementById("batteryIcon").style.backgroundImage = "url(contents/battery/" + battlevel + ".png)";
});

api.system.observeData(function(systemData) {
    loadTime(systemData);
});

api.weather.observeData(function(weatherData) {
    loadWeather(weatherData);
});

api.apps.observeData(function(appData) {
    loadApps(appData);
});

api.media.observeData(function(musicData) {
    loadMusic(musicData);
});

function mainUpdate(type) {
    checker = true;
    if(type == "statusbar") {

        var wifiStat = (wifiName),
            wifiConnected = wifiStat == "NA" ? false : true;

        signalIcon.style.backgroundImage = "url(contents/signal/" + signalBars + ".png)"
        signalType.innerHTML = signalNetworkType;
        wifiIcon.style.backgroundImage = "url(contents/wifi/" + wifiBars + ".png)"
        
        if(wifiConnected) {
            wifiIcon.style.display = "block";
            signalType.style.display = "none";
        } else {
            wifiIcon.style.display = "none";
            signalType.style.display = "block";
        }
    }
}


