(function() {
    loadTime(api.system);
    loadWeather(api.weather);
}());


api.resources.observeData(function(resourcesData) {
    var battlevel = Math.ceil((resourcesData.battery.percentage) / 10) * 10;
    document.getElementById("batteryPercent").innerHTML = resourcesData.battery.percentage + "%";
    document.getElementById("batteryIcon").style.backgroundImage = "url(contents/battery/" + battlevel + ".png)";
});

api.system.observeData(function(systemData) {
    loadTime(systemData);
});

api.weather.observeData(function(weatherData) {
    loadWeather(weatherData);
});

function mainUpdate(type) {
    checker = true;
    if(type == "statusbar") {

        var wifiStat = (wifiName),
            wifiConnected = wifiStat == "NA" ? false : true;

        signalIcon.style.backgroundImage = "url(contents/signal/" + signalBars + ".png)"
        signalType.innerHTML = signalNetworkType;
        wifiIcon.style.backgroundImage = "url(contents/wifi/" + wifiBars + ".png)"
        
        if(wifiConnected) {
            wifiIcon.style.display = "block";
            signalType.style.display = "none";
        } else {
            wifiIcon.style.display = "none";
            signalType.style.display = "block";
        }
    }
}