/* global globalVars Drawer macDock lStorage getIconInfo translate current clock desktopIcons*/
var FPI = {},
    doc = document;

    function FPIloaded() {
        loadAppss();
    }
    function loadSystem(){}
    function loadBattery(){}
    function loadStatusBar(){}
    function loadSwitcher(){}
    function loadApps(){}
    function loadMusic(){}
    function loadNotifications(){}
    function loadFolders(){}
    function loadAlarms(){}
    function loadMemory(){}
    function loadWeather(){}
    function deviceUnlocked(){}
    function deviceLocked(){}
    function viewRotated(direction){}
    function loadSettings(settings){}
    function badgeUpdated(bundle){}
    function loadReminders(){}