//////////////////////////////////////////////////////////////////////////////
//VARIABLES
//////////////////////////////////////////////////////////////////////////////

var doc = document;

var mainContainer = doc.getElementById("mainContainer"),
    time = doc.getElementById("time"),
    date = doc.getElementById("date"),
    weather = doc.getElementById("weather"),
    batteryIcon = doc.getElementById("batteryIcon"),
    batteryPercent = doc.getElementById("batteryPercent"),
    signalIcon = doc.getElementById("signalIcon"),
    signalType = doc.getElementById("signalType"),
    wifiIcon = doc.getElementById("wifiIcon");

//////////////////////////////////////////////////////////////////////////////
//FUNCTIONS
//////////////////////////////////////////////////////////////////////////////

function createDOM(params) {
    var element = doc.createElement(params.type);
    if(params.id) {
        element.id = params.id;
    }
    if(params.className) {
        element.className = params.className;
    }
    if(params.innerHTML) {
        element.innerHTML = params.innerHTML;
    }
    if(params.styleImg) {
        element.style.backgroundImage = "url(" + params.styleImg + ")";
    }
    if(params.appender) {
        for(let i = 0; i < params.appender.length; i++) {
            element.appendChild(params.appender[i]);
        }
    }
    return element;
}

function loadTime(systemData) {
    var twelveHour = systemData.isTwentyFourHourTimeEnabled ? false : true;
    theTime({
        amPm: twelveHour,
        addZero: true,
        done: function(timeObj) {
            time.innerHTML = timeObj.hours() + ":" + timeObj.minutes();
            date.innerHTML = timeObj.monthText() + " " + timeObj.date();
        }
    });
}

function checkBattery(resourceData) {
    var battlevel = Math.ceil((resourceData.battery.percentage) / 10) * 10;
    batteryPercent.innerHTML = resourceData.battery.percentage + "%";
    batteryIcon.style.backgroundImage = "url(contents/battery/" + battlevel + ".png)";
}

function loadWeather(weatherData) {
    weather.innerHTML = "In " + weatherData.metadata.address.city + " it's " + weatherData.now.condition.narrative;
}
