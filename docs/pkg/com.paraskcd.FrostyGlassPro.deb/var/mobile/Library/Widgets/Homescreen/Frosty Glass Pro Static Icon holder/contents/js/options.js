var doc = document,
	dockHolder = doc.getElementById("iconHolder");

function checkSettings() {
	dockHolder.style.top = config.verticalPosition + "vh";
	dockHolder.style.left = config.horizontalPosition + "vh";
	dockHolder.style.height = config.heightSize + "vh";
	dockHolder.style.width = config.widthSize + "vh";
	dockHolder.style.backgroundColor = config.dockColor;
	dockHolder.style.borderRadius = config.borderRadius + "px";
	dockHolder.style.webkitBakdropFilter = "blur("+ config.blurIntensity +"px)";
}

checkSettings();