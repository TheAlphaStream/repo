 document.addEventListener('DOMContentLoaded', function() {
	for(i = 0; i < config.rows; i++){
		var div = document.createElement('div');
		var top = (i * config.distanceBetween) + 5;
		div.id = "iconHolder" + i;
		div.className = "container";
		div.style.top = top + "vh";
		div.style.height = config.heightSize + "vh";
		div.style.width = config.widthSize + "vh";
		div.style.backgroundColor = config.dockColor;
		div.style.borderRadius = config.borderRadius + "px";
		div.style.webkitBakdropFilter = "blur("+ config.blurIntensity +"px)";
		document.getElementById('pageContainer').appendChild(div);
	}
});